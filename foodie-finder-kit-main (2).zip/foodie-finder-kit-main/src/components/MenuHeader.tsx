export function MenuHeader() {
  return (
    <div className="menu-header py-6 sm:py-8 px-4 text-center relative overflow-hidden">
      {/* Animated Background Circles - Smaller on mobile */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-5 -left-5 w-20 sm:w-32 h-20 sm:h-32 border border-primary-foreground/20 rounded-full animate-float" />
        <div className="absolute top-10 -right-5 w-16 sm:w-24 h-16 sm:h-24 border border-primary-foreground/15 rounded-full animate-float" style={{ animationDelay: '1s' }} />
      </div>
      
      {/* Content */}
      <div className="relative z-10">
        {/* Ornamental Divider Top */}
        <div className="flex items-center justify-center gap-2 mb-2 opacity-0 animate-fade-in" style={{ animationDelay: '200ms', animationFillMode: 'forwards' }}>
          <div className="h-px w-8 sm:w-12 bg-gradient-to-r from-transparent to-primary-foreground/60" />
          <div className="w-2 h-2 rotate-45 border border-primary-foreground/60" />
          <div className="h-px w-8 sm:w-12 bg-gradient-to-l from-transparent to-primary-foreground/60" />
        </div>

        <p className="font-display text-primary-foreground/80 text-xs tracking-[0.2em] uppercase mb-1 opacity-0 animate-fade-in" style={{ animationDelay: '300ms', animationFillMode: 'forwards' }}>
          Exquisite Dining
        </p>
        
        <h1 className="font-display text-2xl sm:text-3xl md:text-4xl font-bold text-primary-foreground tracking-wide opacity-0 animate-scale-in" style={{ animationDelay: '400ms', animationFillMode: 'forwards' }}>
          Our Menu
        </h1>
        
        <p className="font-body text-primary-foreground/70 text-xs sm:text-sm mt-1 tracking-wider opacity-0 animate-fade-in" style={{ animationDelay: '500ms', animationFillMode: 'forwards' }}>
          Crafted with passion & tradition
        </p>

        {/* Ornamental Divider Bottom */}
        <div className="flex items-center justify-center gap-2 mt-3 opacity-0 animate-fade-in" style={{ animationDelay: '600ms', animationFillMode: 'forwards' }}>
          <div className="h-px w-6 bg-primary-foreground/40" />
          <div className="w-1.5 h-1.5 rotate-45 bg-primary-foreground/60" />
          <div className="w-2.5 h-2.5 rotate-45 border border-primary-foreground/60" />
          <div className="w-1.5 h-1.5 rotate-45 bg-primary-foreground/60" />
          <div className="h-px w-6 bg-primary-foreground/40" />
        </div>
      </div>
    </div>
  );
}
