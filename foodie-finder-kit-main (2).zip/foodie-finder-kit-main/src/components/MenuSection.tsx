import { ReactNode } from "react";

interface MenuSectionProps {
  title: string;
  children: ReactNode;
  delay?: number;
}

export function MenuSection({ title, children, delay = 0 }: MenuSectionProps) {
  return (
    <div 
      className="space-y-6 opacity-0 animate-fade-in-up"
      style={{ animationDelay: `${delay}ms`, animationFillMode: 'forwards' }}
    >
      {/* Section Header */}
      <div className="text-center relative">
        {/* Decorative Lines */}
        <div className="absolute left-0 right-0 top-1/2 transform -translate-y-1/2">
          <div className="h-px bg-gradient-to-r from-transparent via-accent to-transparent" />
        </div>
        
        <span className="relative inline-block bg-background px-4 py-1">
          <h2 className="font-display text-xl sm:text-2xl md:text-3xl font-semibold text-primary tracking-wide">
            {title}
          </h2>
        </span>
        
        {/* Decorative Element */}
        <div className="flex items-center justify-center gap-3 mt-3">
          <div className="h-0.5 w-12 bg-accent rounded-full" />
          <div className="w-2 h-2 rotate-45 bg-accent animate-pulse" />
          <div className="h-0.5 w-12 bg-accent rounded-full" />
        </div>
      </div>
      
      {/* Grid of Items */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-5">
        {children}
      </div>
    </div>
  );
}
