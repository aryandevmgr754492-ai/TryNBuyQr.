export function MenuFooter() {
  return (
    <div className="bg-secondary/50 py-8 px-6 text-center border-t border-border relative overflow-hidden">
      {/* Decorative Background */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-2 left-10 w-6 h-6 border border-accent/30 rotate-45" />
        <div className="absolute bottom-2 right-10 w-8 h-8 border border-accent/20 rotate-45" />
      </div>

      <div className="relative z-10 opacity-0 animate-fade-in" style={{ animationDelay: '1500ms', animationFillMode: 'forwards' }}>
        {/* Decorative Element */}
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className="h-px w-8 bg-accent/40" />
          <div className="w-1.5 h-1.5 rotate-45 bg-accent/60" />
          <div className="h-px w-8 bg-accent/40" />
        </div>
        
        <p className="font-body text-sm text-muted-foreground">
          All prices are inclusive of taxes
        </p>
        <p className="font-body text-xs text-muted-foreground/70 mt-1">
          Please inform our staff of any dietary requirements or allergies
        </p>
        
        {/* Decorative Footer Icon */}
        <div className="mt-5 flex justify-center">
          <div className="w-10 h-10 rounded-full border-2 border-accent/30 flex items-center justify-center animate-pulse">
            <div className="w-4 h-4 rotate-45 bg-accent/40" />
          </div>
        </div>
      </div>
    </div>
  );
}
