export function Watermark() {
  return (
    <div className="fixed inset-0 pointer-events-none z-50 flex items-center justify-center overflow-hidden">
      {/* Diagonal Watermark Pattern */}
      <div className="absolute inset-0 flex items-center justify-center opacity-[0.04]">
        <div 
          className="font-display text-6xl sm:text-8xl lg:text-9xl font-bold text-foreground whitespace-nowrap transform -rotate-45 select-none"
          style={{ 
            textShadow: '0 0 20px rgba(0,0,0,0.1)',
            letterSpacing: '0.1em'
          }}
        >
          tryNBuyQR
        </div>
      </div>
      
      {/* Corner Watermark */}
      <div className="absolute bottom-4 right-4 opacity-20">
        <div className="font-display text-lg sm:text-xl font-semibold text-primary tracking-wider">
          tryNBuyQR
        </div>
      </div>
      
      {/* Top Corner */}
      <div className="absolute top-4 left-4 opacity-20">
        <div className="font-display text-lg sm:text-xl font-semibold text-primary tracking-wider">
          tryNBuyQR
        </div>
      </div>
    </div>
  );
}
