import { MenuItem } from "./MenuItem";
import { MenuSection } from "./MenuSection";
import { MenuHeader } from "./MenuHeader";
import { MenuFooter } from "./MenuFooter";
import { Watermark } from "./Watermark";
import { menuData } from "@/data/menuData";

export function MenuCard() {
  return (
    <div className="min-h-screen bg-background relative">
      {/* Watermark */}
      <Watermark />

      {/* Background Pattern */}
      <div className="fixed inset-0 opacity-[0.02] pointer-events-none">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, hsl(var(--foreground)) 1px, transparent 0)`,
          backgroundSize: '40px 40px'
        }} />
      </div>

      {/* Main Content */}
      <div className="relative z-10">
        {/* Header */}
        <div className="menu-header z-20 shadow-lg">
          <MenuHeader />
        </div>

        {/* Menu Sections */}
        <div className="container mx-auto px-3 sm:px-6 lg:px-8 py-6 sm:py-10 space-y-10 sm:space-y-14">
          <MenuSection title="Starters" delay={200}>
            {menuData.starters.map((item, index) => (
              <MenuItem key={item.name} {...item} index={index} />
            ))}
          </MenuSection>

          {/* Decorative Divider */}
          <div className="flex items-center justify-center py-4">
            <div className="h-px w-32 bg-gradient-to-r from-transparent via-accent to-transparent" />
          </div>

          <MenuSection title="Main Course" delay={400}>
            {menuData.mainCourse.map((item, index) => (
              <MenuItem key={item.name} {...item} index={index} />
            ))}
          </MenuSection>

          {/* Decorative Divider */}
          <div className="flex items-center justify-center py-4">
            <div className="h-px w-32 bg-gradient-to-r from-transparent via-accent to-transparent" />
          </div>

          <MenuSection title="Breads" delay={600}>
            {menuData.breads.map((item, index) => (
              <MenuItem key={item.name} {...item} index={index} />
            ))}
          </MenuSection>

          {/* Decorative Divider */}
          <div className="flex items-center justify-center py-4">
            <div className="h-px w-32 bg-gradient-to-r from-transparent via-accent to-transparent" />
          </div>

          <MenuSection title="Beverages & Desserts" delay={800}>
            {menuData.beveragesAndDesserts.map((item, index) => (
              <MenuItem key={item.name} {...item} index={index} />
            ))}
          </MenuSection>
        </div>

        {/* Footer */}
        <MenuFooter />
      </div>
    </div>
  );
}
