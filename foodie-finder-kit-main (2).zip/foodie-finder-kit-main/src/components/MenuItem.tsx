interface MenuItemProps {
  name: string;
  description: string;
  price: number;
  image: string;
  index: number;
}

export function MenuItem({ name, description, price, image, index }: MenuItemProps) {
  return (
    <div 
      className="group bg-card rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-500 transform hover:-translate-y-2 opacity-0 animate-fade-in-up"
      style={{ animationDelay: `${index * 100}ms`, animationFillMode: 'forwards' }}
    >
      {/* Image Container */}
      <div className="relative h-36 sm:h-44 overflow-hidden">
        <img 
          src={image} 
          alt={name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        {/* Price Badge */}
        <div className="absolute top-2 right-2 sm:top-3 sm:right-3 bg-primary text-primary-foreground px-2 py-1 sm:px-3 sm:py-1.5 rounded-full font-display text-xs sm:text-base font-semibold shadow-lg transform transition-transform duration-300 group-hover:scale-110">
          ₹{price}
        </div>
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      </div>

      {/* Content */}
      <div className="p-2 sm:p-4">
        <h3 className="font-display text-sm sm:text-lg font-semibold text-foreground group-hover:text-primary transition-colors duration-300 truncate">
          {name}
        </h3>
        <p className="font-body text-xs text-muted-foreground mt-0.5 leading-relaxed line-clamp-2 hidden sm:block">
          {description}
        </p>
      </div>
    </div>
  );
}
