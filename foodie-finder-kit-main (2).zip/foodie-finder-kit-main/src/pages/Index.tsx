import { MenuCard } from "@/components/MenuCard";

const Index = () => {
  return <MenuCard />;
};

export default Index;
