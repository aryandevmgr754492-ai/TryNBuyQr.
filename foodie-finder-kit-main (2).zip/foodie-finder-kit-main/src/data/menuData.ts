// Food image imports
import paneerTikka from "@/assets/food/paneer-tikka.jpg";
import chickenTikka from "@/assets/food/chicken-tikka.jpg";
import samosa from "@/assets/food/samosa.jpg";
import tandooriMushroom from "@/assets/food/tandoori-mushroom.jpg";
import butterChicken from "@/assets/food/butter-chicken.jpg";
import dalMakhani from "@/assets/food/dal-makhani.jpg";
import palakPaneer from "@/assets/food/palak-paneer.jpg";
import malaiKofta from "@/assets/food/malai-kofta.jpg";
import chickenBiryani from "@/assets/food/chicken-biryani.jpg";
import butterNaan from "@/assets/food/butter-naan.jpg";
import tandooriRoti from "@/assets/food/tandoori-roti.jpg";
import mangoLassi from "@/assets/food/mango-lassi.jpg";
import gulabJamun from "@/assets/food/gulab-jamun.jpg";
import kheer from "@/assets/food/kheer.jpg";
import masalaRaita from "@/assets/food/masala-raita.jpg";

export interface MenuItemData {
  name: string;
  description: string;
  price: number;
  image: string;
}

export interface MenuData {
  starters: MenuItemData[];
  mainCourse: MenuItemData[];
  breads: MenuItemData[];
  beveragesAndDesserts: MenuItemData[];
}

export const menuData: MenuData = {
  starters: [
    { name: "Paneer Tikka", description: "Marinated cottage cheese grilled to perfection", price: 280, image: paneerTikka },
    { name: "Chicken Tikka", description: "Succulent chicken pieces in aromatic spices", price: 300, image: chickenTikka },
    { name: "Samosa", description: "Crispy pastry with spiced potato filling", price: 80, image: samosa },
    { name: "Tandoori Mushroom", description: "Stuffed mushrooms with herbs and spices", price: 220, image: tandooriMushroom },
  ],
  mainCourse: [
    { name: "Butter Chicken", description: "Tender chicken in rich tomato cream sauce", price: 350, image: butterChicken },
    { name: "Dal Makhani", description: "Black lentils slow-cooked overnight", price: 220, image: dalMakhani },
    { name: "Palak Paneer", description: "Cottage cheese in creamy spinach gravy", price: 260, image: palakPaneer },
    { name: "Malai Kofta", description: "Cheese dumplings in cashew cream sauce", price: 290, image: malaiKofta },
    { name: "Chicken Biryani", description: "Fragrant basmati rice with spiced chicken", price: 320, image: chickenBiryani },
  ],
  breads: [
    { name: "Butter Naan", description: "Soft leavened bread brushed with butter", price: 60, image: butterNaan },
    { name: "Tandoori Roti", description: "Whole wheat bread from clay oven", price: 40, image: tandooriRoti },
  ],
  beveragesAndDesserts: [
    { name: "Mango Lassi", description: "Sweet yogurt drink with fresh mangoes", price: 100, image: mangoLassi },
    { name: "Gulab Jamun", description: "Soft milk dumplings in rose syrup", price: 120, image: gulabJamun },
    { name: "Kheer", description: "Creamy rice pudding with cardamom", price: 130, image: kheer },
    { name: "Masala Raita", description: "Spiced yogurt with fresh vegetables", price: 70, image: masalaRaita },
  ],
};
